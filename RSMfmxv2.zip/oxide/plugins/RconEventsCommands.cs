﻿using ConVar;
using UnityEngine;
using System.Collections.Generic;
using Facepunch;

namespace Oxide.Plugins
{
    [Info("Rcon Events Commands", "Quantum", "1.3.0")]
    [Description("Sends events and adds more commands for rcon clients")]
    class RconEventsCommands : RustPlugin
    {
        #region Int
        private void Init()
        {
            cmd.AddConsoleCommand("rec.getteaminfo", this, nameof(GetTeamInfo));
            cmd.AddConsoleCommand("rec.getteams", this, nameof(GetTeams));
            cmd.AddConsoleCommand("rec.itemlist", this, nameof(GetItemList));
            cmd.AddConsoleCommand("rec.getperms", this, nameof(GetPerms));
            cmd.AddConsoleCommand("rec.getfullgroups", this, nameof(GetFullGroups));
            cmd.AddConsoleCommand("rec.setgrouptitle", this, nameof(SetGroupTitle));
            cmd.AddConsoleCommand("rec.setgrouprank", this, nameof(SetGroupRank));
            cmd.AddConsoleCommand("rec.setgroupparent", this, nameof(SetGroupParent));
        }
        #endregion

        #region GetItemList
        private class ItemInfo
        {
            public string Title;
            public string ShortName;
            public string Description;
            public string Category;
            public int CategoryID;
            public int ID;
            public int Stackable;
        }
        private void GetItemList(ConsoleSystem.Arg arg)
        {
            if (arg.IsAdmin == false)
            {
                return;
            }

            var items = ItemManager.itemList;
            var list = new List<ItemInfo>();

            foreach (var item in items)
            {
                list.Add(new ItemInfo
                {
                    Title = item.displayName.english,
                    ShortName = item.shortname,
                    Description = item.displayDescription.english,
                    Category = item.category.ToString(),
                    CategoryID = (int)item.category,
                    ID = item.itemid,
                    Stackable = item.stackable                    
                }) ;
            }

            arg.ReplyWithObject(list);
        }
        #endregion GetItemList

        #region GetTeams
        private void GetTeams(ConsoleSystem.Arg arg)
        {
            if (arg.IsAdmin == false)
            {
                return;
            }

            arg.ReplyWithObject(RelationshipManager.ServerInstance.teams);
        }
        #endregion GetTeams

        #region GetTeamInfo
        class teamMember
        {
            public string SteamID;
            public string Username;
            public bool Online;
            public bool Leader;
        }
        private void GetTeamInfo(ConsoleSystem.Arg arg)
        {
            if (arg.IsAdmin == false)
            {
                return;
            }

            ulong userID = arg.GetUInt64(0);
            if (userID == 0UL)
            {
                BasePlayer player = arg.GetPlayer(0);
                if ((UnityEngine.Object)player == (UnityEngine.Object)null)
                    return;
                userID = player.userID;
            }
            RelationshipManager.PlayerTeam playersTeam = RelationshipManager.ServerInstance.FindPlayersTeam(userID);
            if (playersTeam == null)
                return;

            var list = new List<teamMember>();

            foreach (ulong member in playersTeam.members)
            {
                var aPlayer = RelationshipManager.FindByID(member);

                bool isLeader;
                if (member == playersTeam.teamLeader)
                {
                    isLeader = true;
                }
                else
                {
                    isLeader = false;
                }

                list.Add(new teamMember
                {
                    SteamID = aPlayer.UserIDString,
                    Username = aPlayer.displayName,
                    Online = aPlayer.IsConnected,
                    Leader =isLeader
                });
            }

            arg.ReplyWithObject(list);
        }
        #endregion GetTeamInfo

        #region GetPerms
        private void GetPerms(ConsoleSystem.Arg arg)
        {
                if (arg.IsAdmin == false)
            {
                return;
            }
            string[] permissions = permission.GetPermissions();

            arg.ReplyWithObject(permissions);
        }
        #endregion GetPerms

        #region GetFullGroups
        private class GroupInfo
        {
            public string Group;
            public int Rank;
            public string Title;
            public string Parent;
            public string[] Permissions;
            public string[] Users;
        }
        private void GetFullGroups(ConsoleSystem.Arg arg)
        {
                if (arg.IsAdmin == false)
            {
                return;
            }
            string[] groups = permission.GetGroups();

            var list = new List<GroupInfo>();

            foreach (var group in groups)
            {
                var users = permission.GetUsersInGroup(group);

                list.Add(new GroupInfo
                {
                    Group = group,
                    Rank = permission.GetGroupRank(group),
                    Title = permission.GetGroupTitle(group),
                    Parent = permission.GetGroupParent(group),
                    Permissions = permission.GetGroupPermissions(group),
                    Users = users
                });
            }

            arg.ReplyWithObject(list);
        }
        #endregion GetFullGroups

        #region SetGroupTitle
        private void SetGroupTitle(ConsoleSystem.Arg arg)
        {
                if (arg.IsAdmin == false)
            {
                return;
            }
            if (!permission.GroupExists(arg.Args[0]))
                return;

            permission.SetGroupTitle(arg.Args[0], arg.Args[1]);

            Puts("Set group: " + arg.Args[0] + " title to: " + arg.Args[1]);
        }
        #endregion SetGroupTitle

        #region SetGroupRank
        private void SetGroupRank(ConsoleSystem.Arg arg)
        {
                if (arg.IsAdmin == false)
            {
                return;
            }
            if (!permission.GroupExists(arg.Args[0]))
                return;

            permission.SetGroupRank(arg.Args[0], int.Parse(arg.Args[1]));
        }
        #endregion SetGroupRank

        #region SetGroupParent
        private void SetGroupParent(ConsoleSystem.Arg arg)
        {
            if (arg.IsAdmin == false)
            {
                return;
            }

            if (!permission.GroupExists(arg.Args[0]))
                return;

            permission.SetGroupParent(arg.Args[0], arg.Args[1]);
        }
        #endregion SetGroupParent
    }
}
